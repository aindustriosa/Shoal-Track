 
#include <stdint.h>

uint32_t bytes_to_uint32(uint8_t byteMSB0,uint8_t byteMSB1,uint8_t byteMSB2,uint8_t byteMSB3){
    uint32_t output;
    output =  (uint32_t)byteMSB0<<24;
    output |= (uint32_t)byteMSB1<<16;
    output |= (uint32_t)byteMSB2<<8;
    output |= (uint32_t)byteMSB3;
    return output;
}

uint32_t bytes_to_int32(uint8_t byteMSB0,uint8_t byteMSB1,uint8_t byteMSB2,uint8_t byteMSB3){
    uint32_t output;
    output =  (int32_t)byteMSB0<<24;
    output |= (int32_t)byteMSB1<<16;
    output |= (int32_t)byteMSB2<<8;
    output |= (int32_t)byteMSB3;
    return output;
}

uint32_t bytes_to_int16(uint8_t byteMSB0,uint8_t byteMSB1){
    uint32_t output;
    output =  (int32_t)byteMSB0<<8;
    output |= (int32_t)byteMSB1;
    return output;
}

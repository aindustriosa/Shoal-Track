// -*- mode: C++ -*-
/**
   @file shoalnet.cpp
   @version 1.0.0

   @section License
   Copyright (C) 2017, Ignacio Gonzalez

   Firware para el control de los nodos y pasarela hacia un PC princiapla
   Utiliza RadioHead, Crypto ChaCha20 y pseudo-Mavlink
   sobre dispositivo ArduinoDue y Hardware de comunicacion RF430 SX1278 LoRa

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
*/


#include "shoalnet_client.h"
#include <Stream.h>


/** Default constructor, uses default SPI address.
   @see SHOALNET_DEFAULT_ADDRESS
*/
ShoalNet::ShoalNet(RHReliableDatagram& manager):
  _manager(manager) {
  memset(bufferRF, 0xBA, sizeof(bufferRF)); //inicializo a valores conocidos
}



/** Power on and prepare for general usage.
   This will activate the device, the cypher and inicialize vectors
*/
uint8_t ShoalNet::initialize(void) {

  if (!_manager.init()) {
    return 0;
  }
  // Defaults after init are 434.0MHz, 13dBm, Bw = 125 kHz, Cr = 4/5, Sf = 128chips/symbol, CRC on

  // The default transmitter power is 13dBm, using PA_BOOST.
  // If you are using RFM95/96/97/98 modules which uses the PA_BOOST transmitter pin, then
  // you can set transmitter powers from 5 to 23 dBm:
  //  driver.setTxPower(23, false);
  // You can optionally require this module to wait until Channel Activity
  // Detection shows no activity on the channel before transmitting by setting
  // the CAD timeout to non-zero:
  //  driver.setCADTimeout(10000);

  //sistema de cifrado:
  //encript DataPacket:
  cipher.setNumRounds(20); //para chacha20_256
  cipher.clear();
  cipher.setKey(route_list.cypher_key, 32);//ajusto la clave
  cipher.setIV(route_list.cypher_iv, 8);
  cipher.setCounter(route_list.cypher_counter, 8);

  subsetCalcCRC = &bufferRF[SHOALNET_CRCPACKET_POS]; //inicializo el array subset
  subsetCalcCRCSize = 5 + 64; //inicialmente esta completo, Header(sin magick)+payload

  subsetPayload = &bufferRF[SHOALNET_PAYLOAD_POS]; //inicializo el array subset
  subsetPayloadSize = 64; //inicialmente esta completo

  return 1;
}


/////////////////////////////////////////////////////////////////
///COMMUNICATION FUNCTIONS
//compone le packete para preguntar por los datos
void ShoalNet::make_msg_payload (shoaldata_t *data_track) {
  packetDecrypt[0] = SHOALNET_MSG_DATA_RESPONSE; //submsg_type (1byte)
  //milisec from node start
  packetDecrypt[1] = (uint8_t)(data_track->timestamp >> 24);
  packetDecrypt[2] = (uint8_t)(data_track->timestamp >> 16);
  packetDecrypt[3] = (uint8_t)(data_track->timestamp >> 8);
  packetDecrypt[4] = (uint8_t)data_track->timestamp;

  packetDecrypt[5] = data_track->timestamp_cycle;

  //Lat(4bytes)int32
  packetDecrypt[6] = (uint8_t)(data_track->latitudeL >> 24);
  packetDecrypt[7] = (uint8_t)(data_track->latitudeL >> 16);
  packetDecrypt[8] = (uint8_t)(data_track->latitudeL >> 8);
  packetDecrypt[9] = (uint8_t)data_track->latitudeL;
  //Lon(4bytes)int32
  packetDecrypt[10] = (uint8_t)(data_track->longitudeL >> 24);
  packetDecrypt[11] = (uint8_t)(data_track->longitudeL >> 16);
  packetDecrypt[12] = (uint8_t)(data_track->longitudeL >> 8);
  packetDecrypt[13] = (uint8_t)data_track->longitudeL;

  //Date (6bytes)int8
  packetDecrypt[14] = data_track->year;
  packetDecrypt[15] = data_track->month;
  packetDecrypt[16] = data_track->day;
  packetDecrypt[17] = data_track->hours;
  packetDecrypt[18] = data_track->minutes;
  packetDecrypt[19] = data_track->seconds;

  //acc(2bytes)
  packetDecrypt[20] = (uint8_t)(data_track->ax >> 8);
  packetDecrypt[21] = (uint8_t)data_track->ax;
  packetDecrypt[22] = (uint8_t)(data_track->ay >> 8);
  packetDecrypt[23] = (uint8_t)data_track->ay;
  packetDecrypt[24] = (uint8_t)(data_track->az >> 8);
  packetDecrypt[25] = (uint8_t)data_track->az;

  //Serial.println(data_track->ax, DEC);
  
  //gy(2bytes)
  packetDecrypt[26] = (uint8_t)(data_track->gx >> 8);
  packetDecrypt[27] = (uint8_t)data_track->gx;
  packetDecrypt[28] = (uint8_t)(data_track->gy >> 8);
  packetDecrypt[29] = (uint8_t)data_track->gy;
  packetDecrypt[30] = (uint8_t)(data_track->gz >> 8);
  packetDecrypt[31] = (uint8_t)data_track->gz;
  //my(2bytes)
  packetDecrypt[32] = (uint8_t)(data_track->mx >> 8);
  packetDecrypt[33] = (uint8_t)data_track->mx;
  packetDecrypt[34] = (uint8_t)(data_track->my >> 8);
  packetDecrypt[35] = (uint8_t)data_track->my;
  packetDecrypt[36] = (uint8_t)(data_track->mz >> 8);
  packetDecrypt[37] = (uint8_t)data_track->mz;

  //press(2bytes)
  packetDecrypt[38] = (uint8_t)(data_track->pressure >> 8);
  packetDecrypt[39] = (uint8_t)data_track->pressure;
  //Serial.println(data_track->pressure, DEC);
  
  //volt(2bytes)
  packetDecrypt[40] = (uint8_t)(data_track->voltage >> 8);
  packetDecrypt[41] = (uint8_t)data_track->voltage;
  //amp(2bytes)
  packetDecrypt[42] = (uint8_t)(data_track->current >> 8);
  packetDecrypt[43] = (uint8_t)data_track->current;

  //temp_int(2bytes)
  packetDecrypt[44] = (uint8_t)(data_track->temp_int >> 8);
  packetDecrypt[45] = (uint8_t)data_track->temp_int;
  //temp_air(2bytes)
  packetDecrypt[46] = (uint8_t)(data_track->temp_air >> 8);
  packetDecrypt[47] = (uint8_t)data_track->temp_air;
  //temp_water(2bytes)
  packetDecrypt[48] = (uint8_t)(data_track->temp_water >> 8);
  packetDecrypt[49] = (uint8_t)data_track->temp_water;
  //LDR_FrontRigth(2bytes)
  packetDecrypt[50] = (uint8_t)(data_track->ldr_fr >> 8);
  packetDecrypt[51] = (uint8_t)data_track->ldr_fr;
  //LDR_FrontLeft(2bytes)
  packetDecrypt[52] = (uint8_t)(data_track->ldr_fl >> 8);
  packetDecrypt[53] = (uint8_t)data_track->ldr_fl;
  //LDR_BackRigth(2bytes)
  packetDecrypt[54] = (uint8_t)(data_track->ldr_br >> 8);
  packetDecrypt[55] = (uint8_t)data_track->ldr_br;
  //LDR_BackLeft(2bytes)
  packetDecrypt[56] = (uint8_t)(data_track->ldr_bl >> 8);
  packetDecrypt[57] = (uint8_t)data_track->ldr_bl;

  /////56 data bytes////

  //Calculo el CRC
  //calculo el checksum
  uint16_t chksum = crc_calculate(packetDecrypt, 58);
  packetDecrypt[58] = (uint8_t)(uint8_t)(chksum & 0xFF);
  packetDecrypt[59] = (uint8_t)(chksum >> 8);

  subsetPayloadSize = 60; //este tamaño es fijo

}

//finaliza elmensge
void ShoalNet::finish_message(void) {
  bufferRF[0] = 0xFE;
  bufferRF[1] = subsetPayloadSize; //tamaño del paqute
  bufferRF[2]++; //incremento el contador de sequencia
  bufferRF[4] = bufferRF[3]; //hacia donde va (al remitente)
  bufferRF[3] = SHOALNET_ADDRESS; //Quein lo envia
  bufferRF[5] = 201; //elcodigode mensage encapsulado
  //a partir del 6 byte empieza el msg_data:
  //hasta 5+subsetPayloadSize
  //calculo el checksum
  uint16_t chksum = crc_calculate(subsetCalcCRC, 5 + subsetPayloadSize);
  bufferRF[6 + subsetPayloadSize] = (uint8_t)(chksum & 0xFF);
  bufferRF[6 + subsetPayloadSize + 1] = (uint8_t)(chksum >> 8);

  packet_len = 6 + subsetPayloadSize + 2; //header, pyload, crc
}


//descompongo el buffer de entrada en sus partes individual: devuelvo si es correcto
uint8_t ShoalNet::parse_packet(uint8_t send_secuence) {
  //comienzo si es init
  if (bufferRF[0] != 0xFE) {
    return 0;
  }
  //compruebo si soy la direccion destino
  if ((bufferRF[4] != SHOALNET_ADDRESS) && (bufferRF[4] != SHOALNET_BROADCAST_ADDRESS)) {
    return 0;
  }

  //compruebo que el mensage es del tipo MSG_ENCAPSULATED_CRYPTO
  if (bufferRF[5] != 201) {
    return 0;
  }
  //compruebo el checksum
  subsetCalcCRCSize = 5 + bufferRF[1]; //sumo el header(sin el magikpacket)+tamaño de payload
  //Calculo el CRC
  uint16_t chksum = crc_calculate(subsetCalcCRC, subsetCalcCRCSize);
  if ((bufferRF[1 + subsetCalcCRCSize] != (uint8_t)(chksum & 0xFF)) || (bufferRF[1 + subsetCalcCRCSize + 1] != (uint8_t)(chksum >> 8))) {
    return 0;
  }

  //coloco el tamño del payload:
  subsetPayloadSize = bufferRF[1];

  return 1;
}


//Compruebo si la pregunta es aceptada
uint8_t ShoalNet::accept_request(void) {
  //submsg_type (1byte) eltipo de mensaje es "data request"
  if (packetDecrypt[0] != SHOALNET_MSG_DATA_REQUEST) {
    //Serial.println(F("#DEBUG,fail msg_header"));
    return 0;
  }

  //TODO: miro que le timestamp sea correcto.. no sea repetido

  //miro que el Checksum es correcto: decodificacion correcta
  //Calculo el CRC y compruebo que los dos resultadosson iguales al final
  uint16_t chksum = crc_calculate(packetDecrypt, subsetPayloadSize - 2);
  if ((packetDecrypt[subsetPayloadSize - 2] != (uint8_t)(chksum & 0xFF)) || (packetDecrypt[subsetPayloadSize - 1] != (uint8_t)(chksum >> 8))) {
    //Serial.println(F("#DEBUG,fail checsum"));
    return 0;
  }

  //el time no sea repetido, y que no este caducado packetDecrypt[7-10]
  return 1;
}






/////////////////////////////////////////////////////////////////
///RESPONSE FUNCTIONS

//Miro si hay una peticion esperando mi respuesta, relleno la respuesto con la estructura
//y obtengo el estado de la operacion
uint8_t ShoalNet::response(shoaldata_t *Data) {
  uint8_t status = 0; //empiezo como fail

  if (_manager.available())  {
    memset(bufferRF, 0xBA, SHOALNET_MAX_PACKET_LEN);
    //Serial.println(F("#DEBUG,incoming data"));

    //espero respuesta  // Now wait for a reply from the server
    packet_len = SHOALNET_MAX_PACKET_LEN; //para que entre toda la trama
    if (_manager.recvfromAckTimeout(bufferRF, &packet_len, SHOALNET_MAX_TIME_WAIT, &packet_from_id)) {
      //Serial.print(F("#DEBUG,recieve from: "));
      //Serial.println(packet_from_id, DEC);
      //compruebo la validez
      if (parse_packet(route_list.secuence)) {
        //Serial.print(F("#DEBUG,secuence: "));
        //Serial.println(route_list.secuence, DEC);
        //ajusto el cypher_counter a los valores del header:
        route_list.cypher_counter[0] = bufferRF[0];//magik
        route_list.cypher_counter[1] = bufferRF[1];//len
        route_list.cypher_counter[2] = bufferRF[2];//shoal_node_secuence
        route_list.cypher_counter[3] = (bufferRF[3] >> 3); //shoal_node_secuence
        route_list.cypher_counter[4] = (bufferRF[3] >> 5); //shoal_node_secuence
        route_list.cypher_counter[5] = bufferRF[3];//from
        route_list.cypher_counter[6] = bufferRF[4];//to
        route_list.cypher_counter[7] = bufferRF[5];//msg_type

        //decodifico el pacjkete con el nuevo counter
        cipher.setCounter(route_list.cypher_counter, 8);
        cipher.decrypt(packetDecrypt, subsetPayload, subsetPayloadSize);

        //Si el packete decodificado es correcto y la respuesta es aceptada, la proceso
        if (accept_request()) {
          //Serial.println(F("#DEBUG,accept request"));
          //preparo la respuesta a partir de datos structurados (Data ya es un pnt. lo paso)
          make_msg_payload(Data);


          //cifro el msg
          cipher.encrypt(subsetPayload, packetDecrypt, subsetPayloadSize); //lo meto directamente sbre el buffer desalida

          //empaqueto todo y calculo su CRC
          finish_message();

          //envio
          _manager.sendtoWait(bufferRF, packet_len, bufferRF[4]);
          //Serial.println(F("#DEBUG,send rescponse"));
          //todo ok
          status = 1;

        }
      }
    }
  }
  return status;
}

// -*- mode: C++ -*-
/**
 * @file shoalnet.cpp
 * @version 1.0.0
 *
 * @section License
 * Copyright (C) 2017, Ignacio Gonzalez
 *
 * Firware para el control de los nodos y pasarela hacia un PC princiapla
 * Utiliza RadioHead, Crypto ChaCha20 y pseudo-Mavlink
 * sobre dispositivo ArduinoDue y Hardware de comunicacion RF430 SX1278 LoRa
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 */


#include "shoalnet.h"
#include <Stream.h>


/** Default constructor, uses default SPI address.
 * @see SHOALNET_DEFAULT_ADDRESS
 */
ShoalNet::ShoalNet(RHReliableDatagram& manager,Stream & port):
  _manager(manager),
  _port_out(port){
    memset(bufferRF, 0xBA, sizeof(bufferRF)); //inicializo a valores conocidos
}

void ShoalNet::set_port_output(Stream & port) {
    
    _port_out = port; //para usar la salida de datos a PC

    #ifdef VERBOSE_OUTPUT
        Serial.print(F("#DEBUG,[ComLinkRF], Configure Output Port "));
    #endif
}

/** Power on and prepare for general usage.
 * This will activate the device, the cypher and inicialize vectors
 */
void ShoalNet::initialize(void) {

    if (!_manager.init()){
    #ifdef VERBOSE_OUTPUT
        _port_out.print(F("#DEBUG,[ComLinkRF], init RHReliableDatagram failed.. "));
    #endif
    }
  // Defaults after init are 434.0MHz, 13dBm, Bw = 125 kHz, Cr = 4/5, Sf = 128chips/symbol, CRC on

  // The default transmitter power is 13dBm, using PA_BOOST.
  // If you are using RFM95/96/97/98 modules which uses the PA_BOOST transmitter pin, then 
  // you can set transmitter powers from 5 to 23 dBm:
//  driver.setTxPower(23, false);
  // You can optionally require this module to wait until Channel Activity
  // Detection shows no activity on the channel before transmitting by setting
  // the CAD timeout to non-zero:
//  driver.setCADTimeout(10000);

  //sistema de cifrado:
  //encript DataPacket:
  cipher.setNumRounds(20); //para chacha20_256
  cipher.clear();
  cipher.setKey(route_list[0].cypher_key, 32);//ajusto la clave
  cipher.setIV(route_list[0].cypher_iv, 8);
  cipher.setCounter(route_list[0].cypher_counter, 8);

  subsetCalcCRC = &bufferRF[SHOALNET_CRCPACKET_POS]; //inicializo el array subset
  subsetCalcCRCSize = 5+64; //inicialmente esta completo, Header(sin magick)+payload

  subsetPayload = &bufferRF[SHOALNET_PAYLOAD_POS]; //inicializo el array subset
  subsetPayloadSize = 64; //inicialmente esta completo

  #ifdef VERBOSE_OUTPUT
    Serial.print(F("#DEBUG,[ComLinkRF], init OK: address: "));
    Serial.println(SHOALNET_ADDRESS, DEC);
    
    Serial.print(F("#DEBUG,[ComLinkRF], Nodes: "));
    Serial.println(NUMBER_ADDRESS_USED, DEC);
  #endif
  

  
}
  
  
/////////////////////////////////////////////////////////////////
///COMMUNICATION FUNCTIONS
//compone le packete para preguntar por los datos
void ShoalNet::make_msg_payload (uint8_t cycle_time){
  uint32_t timemillis = millis();
  
  packetDecrypt[0]=SHOALNET_MSG_DATA_REQUEST;//submsg_type (1byte) eltipo de mensaje es "data request"
  //milisec from node start
  packetDecrypt[1]=(uint8_t)(timemillis >> 24);
  packetDecrypt[2]=(uint8_t)(timemillis >> 16);
  packetDecrypt[3]=(uint8_t)(timemillis >> 8);
  packetDecrypt[4]=(uint8_t)timemillis;
  packetDecrypt[5]=cycle_time;
  
  ////6 data bytes//// 

  //Calculo el CRC
  //calculo el checksum
  uint16_t chksum = crc_calculate(packetDecrypt, 6);
  packetDecrypt[6]=(uint8_t)(uint8_t)(chksum& 0xFF);
  packetDecrypt[7]=(uint8_t)(chksum >> 8);

  subsetPayloadSize = 8; //este tamaño es fijo
}

//finaliza elmensge
void ShoalNet::finish_message(void){
  //a partir del 6 byte empieza el msg_data:
  //hasta 5+subsetPayloadSize
  //calculo el checksum
  uint16_t chksum = crc_calculate(subsetCalcCRC, 5+subsetPayloadSize);
  bufferRF[6+subsetPayloadSize]=(uint8_t)(chksum& 0xFF);
  bufferRF[6+subsetPayloadSize+1]=(uint8_t)(chksum >> 8);

  packet_len = 6+subsetPayloadSize+2;//header, pyload, crc
}


//descompongo el buffer de entrada en sus partes individual: devuelvo si es correcto
uint8_t ShoalNet::parse_packet(uint8_t send_secuence){
  //comienzo si es init
  if (bufferRF[0] != 0xFE){
    #ifdef VERBOSE_OUTPUT
        _port_out.println(F("#DEBUG,[ComLinkRF], Incorrect magick number"));
    #endif 
    return 0;
  }
  //compruebo si soy la direccion destino
  if ((bufferRF[4]!=SHOALNET_ADDRESS) && (bufferRF[4]!=SHOALNET_BROADCAST_ADDRESS)){
    #ifdef VERBOSE_OUTPUT
        _port_out.print(F("#DEBUG,[ComLinkRF], Incorrect address: "));
        _port_out.println(bufferRF[4], DEC);
    #endif 
    return 0;
  }

  //compruebo que la secuencia recibida es consecutiva a la enviada
  if (bufferRF[2]!=send_secuence+1){
    #ifdef VERBOSE_OUTPUT
        _port_out.print(F("#DEBUG,[ComLinkRF], Incorrect secuence: "));
        _port_out.print(bufferRF[2], DEC);
        _port_out.print(F(", Correct secuence: "));
        _port_out.println(send_secuence+1, DEC);
    #endif 
    return 0;
  }
  
  //compruebo que el mensage es del tipo MSG_ENCAPSULATED_CRYPTO
  if (bufferRF[5]!=201){
    #ifdef VERBOSE_OUTPUT
        _port_out.println(F("#DEBUG,[ComLinkRF], Incorrect msg_type"));
    #endif 
    return 0;
  }
  //compruebo el checksum
  subsetCalcCRCSize = 5+bufferRF[1]; //sumo el header(sin el magikpacket)+tamaño de payload
  //Calculo el CRC
  uint16_t chksum = crc_calculate(subsetCalcCRC, subsetCalcCRCSize);
  if ((bufferRF[1+subsetCalcCRCSize]!=(uint8_t)(chksum& 0xFF))||(bufferRF[1+subsetCalcCRCSize+1]!=(uint8_t)(chksum >> 8))){
    #ifdef VERBOSE_OUTPUT
        _port_out.println(F("#DEBUG,[ComLinkRF], Incorrect CRC "));
    #endif 
    return 0;
   }

   //coloco el tamño del payload:
   subsetPayloadSize = bufferRF[1];
   
  return 1;
}


//Compruebo si la pregunta es aceptada
uint8_t ShoalNet::accept_request(void){
  //eltipo de mensaje es "respond to data request"
  if (packetDecrypt[0] != SHOALNET_MSG_DATA_RESPONSE){
    #ifdef VERBOSE_OUTPUT
        _port_out.print(F("#DEBUG,[ComLinkRF], Fail MSG_TYPE: "));
        _port_out.println(packetDecrypt[0],DEC);
    #endif
     return 0;
  }

  //TODO: miro que le timestamp sea correcto.. no sea repetido
  
  //miro que el Checksum es correcto: decodificacion correcta
  //Calculo el CRC y compruebo que los dos resultadosson iguales al final
  uint16_t chksum = crc_calculate(packetDecrypt, subsetPayloadSize-2);
  if ((packetDecrypt[subsetPayloadSize-2]!=(uint8_t)(chksum& 0xFF))||(packetDecrypt[subsetPayloadSize-1]!=(uint8_t)(chksum >> 8))){
    #ifdef VERBOSE_OUTPUT
        _port_out.println(F("#DEBUG,[ComLinkRF], Fail checksum: "));
    #endif
    return 0;
   }
  
   //el time no sea repetido, y que no este caducado packetDecrypt[7-10]
   return 1;
}


uint8_t ShoalNet::parse_data(shoaldata_t *data_track){
  //inicializo la variable a valores 0x00
  //memset(&data_track, 0, sizeof(data_track));
  //recompone las variables:
    
  //meter la identificacion deL NODO cada nodo!!
  data_track->nameid =bufferRF[3]; 
    
  data_track->timestamp = bytes_to_uint32(packetDecrypt[1],packetDecrypt[2],packetDecrypt[3],packetDecrypt[4]);
  data_track->timestamp_cycle =packetDecrypt[5];

  data_track->latitudeL = bytes_to_int32(packetDecrypt[6],packetDecrypt[7],packetDecrypt[8],packetDecrypt[9]);
  data_track->longitudeL = bytes_to_int32(packetDecrypt[10],packetDecrypt[11],packetDecrypt[12],packetDecrypt[13]);

  data_track->year =packetDecrypt[14];
  data_track->month =packetDecrypt[15];
  data_track->day =packetDecrypt[16];
  data_track->hours =packetDecrypt[17];
  data_track->minutes =packetDecrypt[18];
  data_track->seconds =packetDecrypt[19];
    
  data_track->ax = bytes_to_int16(packetDecrypt[20],packetDecrypt[21]);
  data_track->ay = bytes_to_int16(packetDecrypt[22],packetDecrypt[23]);
  data_track->az = bytes_to_int16(packetDecrypt[24],packetDecrypt[25]);

  data_track->gx = bytes_to_int16(packetDecrypt[26],packetDecrypt[27]);
  data_track->gy = bytes_to_int16(packetDecrypt[28],packetDecrypt[29]);
  data_track->gz = bytes_to_int16(packetDecrypt[30],packetDecrypt[31]);

  data_track->mx = bytes_to_int16(packetDecrypt[32],packetDecrypt[33]);
  data_track->my = bytes_to_int16(packetDecrypt[34],packetDecrypt[35]);
  data_track->mz = bytes_to_int16(packetDecrypt[36],packetDecrypt[37]);

  data_track->pressure = bytes_to_int16(packetDecrypt[38],packetDecrypt[39]);

  data_track->voltage = bytes_to_int16(packetDecrypt[40],packetDecrypt[41]);
  data_track->current = bytes_to_int16(packetDecrypt[42],packetDecrypt[43]);

  data_track->temp_int = bytes_to_int16(packetDecrypt[44],packetDecrypt[45]);
  data_track->temp_air = bytes_to_int16(packetDecrypt[46],packetDecrypt[47]);
  data_track->temp_water = bytes_to_int16(packetDecrypt[48],packetDecrypt[49]);

  data_track->ldr_fr = bytes_to_int16(packetDecrypt[50],packetDecrypt[51]);
  data_track->ldr_fl = bytes_to_int16(packetDecrypt[52],packetDecrypt[53]);
  data_track->ldr_br = bytes_to_int16(packetDecrypt[54],packetDecrypt[55]);
  data_track->ldr_bl = bytes_to_int16(packetDecrypt[56],packetDecrypt[57]);
  
  return 1;
  
  }



///////////////////////////////////////////////
//EXTERN FUNCTIONS

//saca el los datos por la salida del Concetnrador
void ShoalNet::relay_to_output(shoaldata_t *data_track){
  //imprimo
  _port_out.write('$');
  //localizo su identificador y escribo su codigo ASCII
  for(uint8_t i=0; i<SHOALNET_ROUTE_LEN; i++) {
    if (data_track->nameid == route_list[i].address){
        for(uint8_t j=0; j<6; j++) {
            _port_out.print(route_list[i].code[j]);
        }
        break;
    }
    
  }
  _port_out.print(',');
  _port_out.print(data_track->schemaid, DEC);
  
  _port_out.print(',');
  _port_out.print(data_track->timestamp, DEC);
  _port_out.write(',');
  _port_out.print(data_track->timestamp_cycle, DEC);
  _port_out.write(',');

  _port_out.print(data_track->latitudeL, DEC);
  _port_out.write(',');
  _port_out.print(data_track->longitudeL, DEC);
  _port_out.write(',');
  _port_out.print(data_track->year, DEC);
  _port_out.write(',');
  _port_out.print(data_track->month, DEC);
  _port_out.write(',');
  _port_out.print(data_track->day, DEC);
  _port_out.write(',');
  _port_out.print(data_track->hours, DEC);
  _port_out.write(',');
  _port_out.print(data_track->minutes, DEC);
  _port_out.write(',');
  _port_out.print(data_track->seconds, DEC);
  _port_out.write(',');
  
  _port_out.print(data_track->ax, DEC);
  _port_out.write(',');
  _port_out.print(data_track->ay, DEC);
  _port_out.write(',');
  _port_out.print(data_track->az, DEC);
  _port_out.write(',');
  _port_out.print(data_track->gx, DEC);
  _port_out.write(',');
  _port_out.print(data_track->gy, DEC);
  _port_out.write(',');
  _port_out.print(data_track->gz, DEC);
  _port_out.write(',');
  _port_out.print(data_track->mx, DEC);
  _port_out.write(',');
  _port_out.print(data_track->my, DEC);
  _port_out.write(',');
  _port_out.print(data_track->mz, DEC);
  _port_out.write(',');

  _port_out.print(data_track->pressure, DEC);
  _port_out.write(',');

  _port_out.print(data_track->voltage, DEC);
  _port_out.write(',');
  _port_out.print(data_track->current, DEC);
  _port_out.write(',');

  _port_out.print(data_track->temp_int, DEC);
  _port_out.write(',');
  _port_out.print(data_track->temp_air, DEC);
  _port_out.write(',');
  _port_out.print(data_track->temp_water, DEC);
  _port_out.write(',');
  
  _port_out.print(data_track->ldr_fr, DEC);
  _port_out.write(',');
  _port_out.print(data_track->ldr_fl, DEC);
  _port_out.write(',');
  _port_out.print(data_track->ldr_br, DEC);
  _port_out.write(',');
  _port_out.print(data_track->ldr_bl, DEC);
  _port_out.print(",00\n");

  /*
   * Examples:
   * $DTSR,720287,0,720287,0,0,0,0,0,0,0,0,0,0,709,733,-12700,-12700,0,735,730,724,719,00␊
   * $DTSR,721897,0,721897,0,0,0,0,0,0,0,0,0,0,618,629,-12700,-12700,0,625,596,585,591,00␊
   * $DTSR,723787,0,723787,0,0,0,0,0,0,0,0,0,0,649,646,-12700,-12700,0,655,634,626,629,00␊
   * $DTSR,725786,0,725786,0,0,0,0,0,0,0,0,0,0,665,684,-12700,-12700,0,676,655,647,652,00␊
   * $DTSR,727635,0,727635,0,0,0,0,0,0,0,0,0,0,627,628,-12700,-12700,0,640,606,597,602,00␊
   */
  
}





/////////////////////////////////////////////////////////////////
///REQUEST FUNCTIONS

//hago una petions de datos a una direccion, relleno la estructura 
//y obtengo el estado de la operacion
uint8_t ShoalNet::request_to(uint8_t shoal_node, shoaldata_t *Data,uint8_t cycle_time){
    uint8_t status = 0; //empiezo como fail
    uint8_t route_id = 0;
    
    //localizo su identificador y escribo su identificaion de la posicion
    for(uint8_t i=0; i<SHOALNET_ROUTE_LEN; i++) {
        if (route_list[i].address == shoal_node){
            route_id = i;
            break;
        }
    }
    
    memset(bufferRF, 0xBA, sizeof(bufferRF)); //inicializo a valores conocidos
    
    #ifdef VERBOSE_OUTPUT
        _port_out.print(F("#DEBUG,[ComLinkRF], Request to: "));
        _port_out.println(shoal_node);
    #endif
        
    //preparo la pregunta:
    make_msg_payload(cycle_time);
    #ifdef VERBOSE_OUTPUT
        _port_out.println(F("#DEBUG,[ComLinkRF], generate pyload"));
    #endif
    
    //incremento el contador de secuencia:
    route_list[route_id].secuence++;
        
    //preparo la cabezera:
    bufferRF[0]=0xFE; //magik
    bufferRF[1]=subsetPayloadSize;//tamaño del paqute
    bufferRF[2]= route_list[route_id].secuence;
    bufferRF[3]= SHOALNET_GATEWAY_ADDRESS; //Quien lo envia
    bufferRF[4]=shoal_node; //hacia donde va (al remitente)
    bufferRF[5]=201;//elcodigode mensage encapsulado
       
    //ajusto el cypher_counter a los valores del header:
    
    route_list[route_id].cypher_counter[0] = bufferRF[0];//magik 
    route_list[route_id].cypher_counter[1] = bufferRF[1];//len
    route_list[route_id].cypher_counter[2] = bufferRF[2];//shoal_node_secuence
    route_list[route_id].cypher_counter[3] = (bufferRF[3]>>3);//shoal_node_secuence
    route_list[route_id].cypher_counter[4] = (bufferRF[3]>>5);//shoal_node_secuence
    route_list[route_id].cypher_counter[5] = bufferRF[3];//from
    route_list[route_id].cypher_counter[6] = bufferRF[4];//to
    route_list[route_id].cypher_counter[7] = bufferRF[5];//msg_type
    
    //configuro el cifrado
    cipher.clear();
    cipher.setKey(route_list[route_id].cypher_key, 32);//ajusto la clave
    cipher.setIV(route_list[route_id].cypher_iv, 8);
    cipher.setCounter(route_list[route_id].cypher_counter, 8);

    
    //cifro el msg
    cipher.encrypt(subsetPayload, packetDecrypt, subsetPayloadSize); //lo meto directamente sbre el buffer desalida

    //empaqueto todo y calculo su CRC
    finish_message();
    
    //lo envío // Send a message to client node
    if (_manager.sendtoWait(bufferRF, packet_len, bufferRF[4])) {

        //espero respuesta  // Now wait for a reply from the server
        packet_len =SHOALNET_MAX_PACKET_LEN; //para que entre toda la trama
        if (_manager.recvfromAckTimeout(bufferRF, &packet_len, SHOALNET_MAX_TIME_WAIT, &packet_from_id)) {
            #ifdef VERBOSE_OUTPUT
                _port_out.print(F("#DEBUG,[ComLinkRF], Recieve Request: "));
                _port_out.println(packet_from_id);
            #endif 

            //compruebo la validez
            if (parse_packet(route_list[route_id].secuence)){
                //desencripto
                cipher.decrypt(packetDecrypt, subsetPayload, subsetPayloadSize);
                //Si el packete decodificado es correcto y la respuesta es aceptada, la proceso
                if (accept_request()){
                    //transformo a datos estructurados (Data yaes un puntero... simplemente lo paso)
                    status = parse_data(Data);
                }else {
                    #ifdef VERBOSE_OUTPUT
                        _port_out.println(F("#DEBUG,[ComLinkRF], Fail to accept msg"));
                    #endif 
                }
            }else {
                #ifdef VERBOSE_OUTPUT
                    _port_out.println(F("#DEBUG,[ComLinkRF], Fail to parse packet"));
                #endif 
            }
        }else {
            #ifdef VERBOSE_OUTPUT
                _port_out.println(F("#DEBUG,[ComLinkRF], No reply for client"));
            #endif 
        }
    }else{
        #ifdef VERBOSE_OUTPUT
            _port_out.println(F("#DEBUG,[ComLinkRF], sendtoWait failed"));
        #endif 
    }

    return status;
    
}

//definicion de las variables prncipales

//#define DEBUG_MODE 1 // 0 disable; 1 enable

//#define VERBOSE_OUTPUT 1 //0 diasble; 1 enable

#define SHOALNET_ADDRESS 0
#define NUMBER_ADDRESS_USED 11


// -*- mode: C++ -*-
#ifndef _UTILS_H_
#define _UTILS_H_

/// NMEA ShoalData
struct time_millis_t {
    uint32_t timestamp;       //es en milisegundos: 32bits = 4294967296 miliseg = 49 dias
    uint8_t timestamp_cycle;  //el ciclo del tiemstamp 49x255= 34 años
    
    void init() {
        timestamp = 0;
        timestamp_cycle=0;
    }
};

uint32_t bytes_to_uint32(uint8_t byteMSB0,uint8_t byteMSB1,uint8_t byteMSB2,uint8_t byteMSB3);

uint32_t bytes_to_int32(uint8_t byteMSB0,uint8_t byteMSB1,uint8_t byteMSB2,uint8_t byteMSB3);

uint32_t bytes_to_int16(uint8_t byteMSB0,uint8_t byteMSB1);

#endif /* _UTILS_H_ */

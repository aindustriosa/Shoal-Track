//definicion de las variables prncipales

#define SHOALNET_ADDRESS 7

//HARDWARE CONFIGURE:
//LED status
#define LED_STATUS 3

//LDR light
#define LDRPIN_FR A0
#define LDRPIN_FL A1
#define LDRPIN_BR A2
#define LDRPIN_BL A3

//power:
#define VOLTPIN A7
#define AMPPIN A6

//Pressure:
#define BMP280_CALIBRATRION_NP 73

// -*- mode: C++ -*-
#ifndef _SHOALNET_H_
#define _SHOALNET_H_

//------------------------------------------------------
// @file shoalnet.h
// @version 1.0.0
//
// @section License
// Copyright (C) 2016, Ignacio Gonzalez
//
//Firware para el control de los nodos y pasarela hacia un PC princiapla
// Utiliza RadioHead, Crypto ChaCha20 y pseudo-Mavlink
// sobre dispositivo ArduinoDue y Hardware de comunicacion RF430 SX1278 LoRa

// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

//include 
#include "config.h"

#include <RHReliableDatagram.h>
#include <RH_RF95.h>
#include <SPI.h>

#include <Crypto.h>
#include <ChaCha.h>
#include <avr/pgmspace.h>

#include "checksum.h"
#include "utils.h"

//lista de direciones estaticas: su IP
#define SHOALNET_BROADCAST_ADDRESS 255
#define SHOALNET_GATEWAY_ADDRESS 0
#define SHOALNET_NODE_RMRK01_ADDRESS 1
#define SHOALNET_NODE_RMRK02_ADDRESS 2
#define SHOALNET_NODE_RMRK03_ADDRESS 3
#define SHOALNET_NODE_RMRK04_ADDRESS 4
#define SHOALNET_NODE_RMRK05_ADDRESS 5
#define SHOALNET_NODE_RMRK06_ADDRESS 6
#define SHOALNET_NODE_RMRK07_ADDRESS 7
#define SHOALNET_NODE_RMRK08_ADDRESS 8
#define SHOALNET_NODE_RMRK09_ADDRESS 9
#define SHOALNET_NODE_RMRK010_ADDRESS 10

#define SHOALNET_NODE_ASRS01_ADDRESS 21
#define SHOALNET_NODE_ASRS02_ADDRESS 22
#define SHOALNET_NODE_ASRS03_ADDRESS 23
#define SHOALNET_NODE_ASRS04_ADDRESS 24
#define SHOALNET_NODE_ASRS05_ADDRESS 25
#define SHOALNET_NODE_ASRS06_ADDRESS 26
#define SHOALNET_NODE_ASRS07_ADDRESS 27
#define SHOALNET_NODE_ASRS08_ADDRESS 28
#define SHOALNET_NODE_ASRS09_ADDRESS 29
#define SHOALNET_NODE_ASRS010_ADDRESS 30
#define SHOALNET_NODE_ASRS011_ADDRESS 31
#define SHOALNET_NODE_ASRS012_ADDRESS 32
#define SHOALNET_NODE_ASRS013_ADDRESS 33
#define SHOALNET_NODE_ASRS014_ADDRESS 34
#define SHOALNET_NODE_ASRS015_ADDRESS 35

 

////////////////////////////////////////
//Variables de trasmision de datos RF:
#define SHOALNET_MAX_TIME_WAIT 500 //en milisegundos
#define SHOALNET_MAX_PACKET_LEN 70
#define SHOALNET_MAX_PAYLOAD_LEN 64
#define SHOALNET_CRCPACKET_POS 1 //la posicion donde comienza la trama donde se calcula el CRC
#define SHOALNET_PAYLOAD_POS 6 //la posicion donde comienza el payload

///////////////////////////////////////
//TYPE MESSAGES
#define SHOALNET_MSG_DATA_REQUEST 11
#define SHOALNET_MSG_DATA_RESPONSE 12


//variables de criptografia para los nodos: el 0 es el servidor, los onodos comienzan en el 1

struct shoalroute_t {
    uint8_t address;
    char code[8];
    uint8_t cypher_key[32];
    uint8_t cypher_iv[8];
    uint8_t cypher_counter[8];
    uint8_t secuence;
};


static shoalroute_t route_list = { 0,"ASRS08",
                                   {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
                                             201, 202, 203, 204, 205, 206, 207, 208, 209, 210,211, 212, 213, 214, 215, 234},
                                    {101,102,103,104,105,106,107,108},
                                    {109, 110, 111, 112, 113, 114, 115, 116},
                                    0
                                  };

                              
/// NMEA ShoalData
struct shoaldata_t {
    uint8_t nameid;
    uint32_t timestamp;
    uint8_t timestamp_cycle;
    
    uint8_t schemaid;

    int32_t  latitudeL;
    int32_t  longitudeL;
    int8_t year;
    int8_t month;
    int8_t day;
    int8_t hours;
    int8_t minutes;
    int8_t seconds;
    
    
    //aceleracion m/s2
    int16_t ax;
    int16_t ay;
    int16_t az;

    //rad/seg
    int16_t gx;
    int16_t gy;
    int16_t gz;

    //
    int16_t mx;
    int16_t my;
    int16_t mz;

    //milibar
    int16_t pressure;

    //intensidad
    int16_t ldr_fr;
    int16_t ldr_fl;
    int16_t ldr_br;
    int16_t ldr_bl;

    //milivoltios
    int16_t voltage;
    //miliamperios
    int16_t current;

    //gradosºCx100
    int16_t temp_int;
    int16_t temp_air;
    int16_t temp_water;
    
    void init() {
        nameid = SHOALNET_ADDRESS;
        timestamp = 0;
        timestamp_cycle=0;
        
        schemaid=15;

        latitudeL = -500;
        longitudeL = -500;
        year = -1;
        month= -1;
        day= -1;
        hours= -1;
        minutes= -1;
        seconds= -1;
    
        //aceleracion m/s2
        ax=0;
        ay=0;
        az=0;

        //rad/seg
        gx=0;
        gy=0;
        gz=0;

        //magnetometro
        mx=0;
        my=0;
        mz=0;

        //milibar
        pressure=0;
        
        //milivoltios
        voltage=0;
        //miliamperios
        current=512;
        
         //gradosºCx100
        temp_int=2000;
        temp_air=2000;
        temp_water=2000;

        //intensidad lux
        ldr_fr=1023;
        ldr_fl=1023;
        ldr_br=1023;
        ldr_bl=1023;
    }
};




class ShoalNet {
    public:
        ShoalNet(RHReliableDatagram& manager);
        uint8_t initialize(void);
        
        uint8_t response(shoaldata_t *Data);
        
        
    private:
        uint8_t nameid =SHOALNET_ADDRESS; //unico para cada dispositivo
        void make_msg_payload (shoaldata_t *data_track);
        void finish_message(void);
        uint8_t parse_packet(uint8_t send_secuence);
        uint8_t accept_request(void);
        uint8_t parse_data(shoaldata_t *data_track, uint8_t cycle_time);
        
        //class for cypher
        ChaCha cipher;
        
        /// The Driver we are to use
        RHReliableDatagram&        _manager;
        
        uint8_t bufferRF[SHOALNET_MAX_PACKET_LEN];
        uint8_t *subsetCalcCRC; //el array virtual donde esta la trama donde se calcula el CRC
        uint8_t subsetCalcCRCSize; //el tamaño de la trama donde se calcula el CRC
        uint8_t *subsetPayload; //el array virtual donde esta el payload
        uint8_t subsetPayloadSize; //el tamaño del payload

        uint8_t packetCrypt[SHOALNET_MAX_PAYLOAD_LEN];
        uint8_t packetDecrypt[SHOALNET_MAX_PAYLOAD_LEN];
        uint8_t packet_len =SHOALNET_MAX_PACKET_LEN;
        uint8_t packet_from_id = 0;
        
};


#endif /* _SHOALNET_H_ */
